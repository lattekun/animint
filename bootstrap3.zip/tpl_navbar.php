<?php
/**
 * DokuWiki Bootstrap3 Template: Navbar
 *
 * @link     http://dokuwiki.org/template:bootstrap3
 * @author   Giuseppe Di Terlizzi <giuseppe.diterlizzi@gmail.com>
 * @license  GPL 2 (http://www.gnu.org/licenses/gpl.html)
 */

// must be run from within DokuWiki
if (!defined('DOKU_INC')) die();

global $lang;

$navbar_labels    = bootstrap3_conf('navbarLabels');
$navbar_classes   = array();
$navbar_classes[] = (bootstrap3_conf('fixedTopNavbar') ? 'navbar-fixed-top' : null);
$navbar_classes[] = (bootstrap3_conf('inverseNavbar')  ? 'navbar-inverse'   : 'navbar-default');

?>

<nav class="navbar <?php echo trim(implode(' ', $navbar_classes)) ?>" role="navigation">

  <div class="container<?php echo (bootstrap3_is_fluid_navbar() ? '-fluid' : '') ?>">

    <div class="navbar-header">

      <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

    <a class="navbar-brand" rel="home" href="http://www.animint.net/" title="애니민트넷">애니민트넷</a>

    </div>

<div class="navbar-collapse collapse">
<div class="nav pull-right menu1">
            <a type="button" class="btn btn-default navbar-btn" href="http://www.animint.net/newinfo" rel="nofollow"><i class="fa fa-newspaper-o" aria-hidden="true"></i> 새소식</a>
            <a type="button" class="btn btn-default navbar-btn" href="http://www.animint.net/freebd" rel="nofollow"><i class="fa fa-sticky-note-o" aria-hidden="true"></i> 자유스레</a>
            <a type="button" class="btn btn-default navbar-btn" href="http://www.animint.net/comicbd" rel="nofollow"><i class="fa fa-cube" aria-hidden="true"></i> 작품스레</a>
            <a type="button" class="btn btn-default navbar-btn" href="http://www.animint.net/note/"><i class="fa fa-book" aria-hidden="true"></i> 작품노트</a>
<?PHP if (class_exists(Context)) {
          $logged_info = Context::get("logged_info");
          if($logged_info){
          echo "<a type=\"button\" class=\"btn btn-default navbar-btn\" href=\"http://www.animint.net/note/?do=admin&page=userhistory&user=".$logged_info->user_id."\" rel=\"nofollow\"><i class=\"fa fa-user\" aria-hidden=\"true\"></i> 기여목록</a>
          <a type=\"button\" class=\"btn btn-default navbar-btn\" href=\"http://www.animint.net/?act=dispMemberLogout\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> 로그아웃</a>";
          } else {
          echo "<a type=\"button\" class=\"btn btn-default navbar-btn\" href=\"http://www.animint.net/?act=dispMemberSignUpForm\" rel=\"nofollow\"><i class=\"fa fa-user-plus\" aria-hidden=\"true\"></i> 회원가입</a>
          <a type=\"button\" class=\"btn btn-default navbar-btn\" href=\"http://www.animint.net/?act=dispMemberLoginForm\" rel=\"nofollow\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> 로그인</a>";
} }?>
    </div>
  </div></div>
</nav>